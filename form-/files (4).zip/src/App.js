import React from 'react';
import TransitForm from './Forms/TransitForm';

function App() {
    return (
        <div className="App">
            <h1>Agency Workflow Magic</h1>
            <TransitForm />
        </div>
    );
}

export default App;